/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.shenjin.objection.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class ObjectionModTabs {
	public static CreativeModeTab TAB_OBJECTION_TAB;

	public static void load() {
		TAB_OBJECTION_TAB = new CreativeModeTab("tab_objection_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(ObjectionModItems.ATTORNEYS_BADGE.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
