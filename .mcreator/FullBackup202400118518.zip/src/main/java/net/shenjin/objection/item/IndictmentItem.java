
package net.shenjin.objection.item;

import net.shenjin.objection.init.ObjectionModTabs;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class IndictmentItem extends Item {
	public IndictmentItem() {
		super(new Item.Properties().tab(ObjectionModTabs.TAB_OBJECTION_TAB).stacksTo(64).rarity(Rarity.COMMON));
	}
}
