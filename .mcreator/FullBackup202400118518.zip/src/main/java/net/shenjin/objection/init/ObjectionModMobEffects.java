/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.shenjin.objection.init;

import net.shenjin.objection.potion.ObjectionTimerMobEffect;
import net.shenjin.objection.ObjectionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

public class ObjectionModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ObjectionMod.MODID);
	public static final RegistryObject<MobEffect> OBJECTION_TIMER = REGISTRY.register("objection_timer", () -> new ObjectionTimerMobEffect());
}
