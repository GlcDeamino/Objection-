/*
 *    MCreator note: This file will be REGENERATED on each build.
*/
package net.shenjin.objection.init;

import net.shenjin.objection.item.IndictmentItem;
import net.shenjin.objection.item.AttorneysBadgeItem;
import net.shenjin.objection.ObjectionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

public class ObjectionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ObjectionMod.MODID);
	public static final RegistryObject<Item> ATTORNEYS_BADGE = REGISTRY.register("attorneys_badge", () -> new AttorneysBadgeItem());
	public static final RegistryObject<Item> INDICTMENT = REGISTRY.register("indictment", () -> new IndictmentItem());
	// Start of user code block custom items
	// End of user code block custom items
}
